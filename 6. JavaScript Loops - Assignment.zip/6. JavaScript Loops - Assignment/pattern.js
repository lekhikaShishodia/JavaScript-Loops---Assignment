
//Loop 1 to keep count of rows
for(var i=1;i<=5;i++)
{
    //Loop 2 to keep count of columns
    for(var j=1;j<=i;j++)  
{
    document.write(j+" ") //printing a row
}
document.write("<br>");// moving to next row
}